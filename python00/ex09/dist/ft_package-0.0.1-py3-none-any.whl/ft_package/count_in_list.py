def count_in_list(lst, item):
    """
        Count occurences of item in list
        
        Arguments:
            lst: list to seach in
            item: item to search
        
        Return:
            int: number of occurences
    """

    return lst.count(item)